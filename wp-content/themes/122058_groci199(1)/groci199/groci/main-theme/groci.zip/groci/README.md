=== Groci ===
Contributors: KlbTheme Team
Tags: light, dark, gray, red, responsive-layout, right-sidebar, left-sidebar, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-image-header, featured-images, full-width-template, microformats, post-formats, sticky-post, theme-options, threaded-comments, translation-ready
Requires at least: 4.1
Tested up to: 5.3
Stable tag: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= RELEASE 1.0.0 =
* Initial Release